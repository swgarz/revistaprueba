# Opgaver

Her får du en hurtig adgang til opdateringer og tilbageværende arbejdsopgaver i det redaktionelle workflow.

Du kan klikke på linket ’Opgaver’ i hovedmenuen til venstre for at se hvilke opgaver, der venter. Hver enkelt kan slettes særskilt, hvis de ikke længere er aktuelle.



