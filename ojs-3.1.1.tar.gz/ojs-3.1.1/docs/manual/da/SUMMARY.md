# Summary

* [Introduktion](README.md)
* [Brugerprofil](user-profile.md)
* [Authoring](authoring.md)
* [Bedømmelse](reviewing.md)
* [Indsendelser](submissions.md)
* [Det redaktionelle workflow](editorial-workflow.md)
    * [Indsendelsestrinnet](submission.md)
    * [Bedømmelsestrinnet](review.md)
    * [Manuskriptredigering](copyediting.md)
    * [Produktion](production.md)
* [Numre](issue-management.md)
* [Opgaver](tasks.md)
* [Indstillinger](settings.md)
* [Brugere og roller](users-and-roles.md)
* [Værktøjer](tools.md)
* [Administration](administration.md)

